#!/usr/bin/env node
// tests/run-tests.js
// Run: node tests/run-tests.js
// (Server must be running at http://localhost:3000)

const BASE_URL = process.env.BASE_URL || 'http://localhost:3000'
const API = `${BASE_URL}/api/assignments`

// ── Helpers ──────────────────────────────────────────────────────────────────
let passCount = 0
let failCount = 0
let createdId = ''

const green = (s) => `\x1b[32m${s}\x1b[0m`
const red   = (s) => `\x1b[31m${s}\x1b[0m`
const cyan  = (s) => `\x1b[36m${s}\x1b[0m`
const bold  = (s) => `\x1b[1m${s}\x1b[0m`
const dim   = (s) => `\x1b[2m${s}\x1b[0m`

function pass(name) {
  passCount++
  console.log(`  ${green('✓')} ${name}`)
}

function fail(name, reason) {
  failCount++
  console.log(`  ${red('✗')} ${name}`)
  console.log(`    ${red('→')} ${reason}`)
}

async function req(method, url, body) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json' },
  }
  if (body !== undefined) opts.body = JSON.stringify(body)
  const res = await fetch(url, opts)
  let json
  try { json = await res.json() } catch { json = null }
  return { status: res.status, body: json }
}

function assert(condition, testName, failMsg) {
  if (condition) pass(testName)
  else fail(testName, failMsg)
}

// ── Test Suites ───────────────────────────────────────────────────────────────

async function testListAssignments() {
  console.log(bold('\n📋  GET /api/assignments — List Assignments'))

  // ✅ Success
  const { status, body } = await req('GET', API)
  assert(status === 200, 'returns 200', `expected 200, got ${status}`)
  assert(body.success === true, 'success flag is true', `expected true`)
  assert(typeof body.count === 'number', 'count is a number', `count = ${body.count}`)
  assert(Array.isArray(body.data), 'data is an array', `data type = ${typeof body.data}`)
  assert(body.data.length >= 3, 'has seed data (>=3 items)', `got ${body.data?.length} items`)

  // ✅ Filter by status
  const fStatus = await req('GET', `${API}?status=completed`)
  assert(fStatus.status === 200, '[filter status=completed] returns 200', `${fStatus.status}`)
  assert(
    fStatus.body.data.every((a) => a.status === 'completed'),
    '[filter status=completed] all items have correct status',
    'mismatch'
  )

  // ✅ Filter by priority
  const fPriority = await req('GET', `${API}?priority=high`)
  assert(fPriority.status === 200, '[filter priority=high] returns 200', `${fPriority.status}`)
  assert(
    fPriority.body.data.every((a) => a.priority === 'high'),
    '[filter priority=high] all items have correct priority',
    'mismatch'
  )

  // ✅ Filter by subject
  const fSubject = await req('GET', `${API}?subject=Database`)
  assert(fSubject.status === 200, '[filter subject=Database] returns 200', `${fSubject.status}`)
  assert(
    fSubject.body.data.every((a) => a.subject.toLowerCase().includes('database')),
    '[filter subject=Database] all items match subject',
    'mismatch'
  )

  // ✅ Empty filter result
  const fEmpty = await req('GET', `${API}?status=overdue`)
  assert(fEmpty.status === 200, '[filter status=overdue] returns 200 with empty data', `${fEmpty.status}`)
  assert(fEmpty.body.count === 0, '[filter status=overdue] count is 0', `count = ${fEmpty.body.count}`)
}

async function testCreateAssignment() {
  console.log(bold('\n➕  POST /api/assignments — Create Assignment'))

  // ✅ Minimal valid payload
  const minimal = await req('POST', API, {
    title: 'Test Assignment Minimal',
    subject: 'Testing 101',
    dueDate: '2025-06-01',
  })
  assert(minimal.status === 201, '[minimal] returns 201', `got ${minimal.status}`)
  assert(minimal.body.success === true, '[minimal] success is true', '')
  assert(minimal.body.data?.id, '[minimal] has id in response', `id = ${minimal.body.data?.id}`)
  assert(minimal.body.data?.status === 'pending', '[minimal] default status is pending', `${minimal.body.data?.status}`)
  assert(minimal.body.data?.priority === 'medium', '[minimal] default priority is medium', `${minimal.body.data?.priority}`)

  // ✅ Full payload
  const full = await req('POST', API, {
    title: 'Full Assignment',
    subject: 'Advanced Testing',
    description: 'A comprehensive test assignment.',
    dueDate: '2025-07-15',
    status: 'in-progress',
    priority: 'high',
    score: null,
    notes: 'Do not skip validation tests.',
  })
  assert(full.status === 201, '[full] returns 201', `got ${full.status}`)
  assert(full.body.data?.status === 'in-progress', '[full] status is in-progress', `${full.body.data?.status}`)
  assert(full.body.data?.priority === 'high', '[full] priority is high', `${full.body.data?.priority}`)
  createdId = full.body.data?.id  // save for later tests

  // ❌ Missing required field: title
  const noTitle = await req('POST', API, { subject: 'Math', dueDate: '2025-05-01' })
  assert(noTitle.status === 422, '[no title] returns 422', `got ${noTitle.status}`)
  assert(noTitle.body.errors?.some((e) => e.field === 'title'), '[no title] error mentions title field', JSON.stringify(noTitle.body.errors))

  // ❌ Missing required field: subject
  const noSubject = await req('POST', API, { title: 'Orphan', dueDate: '2025-05-01' })
  assert(noSubject.status === 422, '[no subject] returns 422', `got ${noSubject.status}`)

  // ❌ Missing required field: dueDate
  const noDueDate = await req('POST', API, { title: 'No Date', subject: 'Math' })
  assert(noDueDate.status === 422, '[no dueDate] returns 422', `got ${noDueDate.status}`)

  // ❌ Invalid dueDate format
  const badDate = await req('POST', API, { title: 'Bad Date', subject: 'Math', dueDate: '01/06/2025' })
  assert(badDate.status === 422, '[bad dueDate] returns 422', `got ${badDate.status}`)
  assert(badDate.body.errors?.some((e) => e.field === 'dueDate'), '[bad dueDate] error mentions dueDate', JSON.stringify(badDate.body.errors))

  // ❌ Invalid status
  const badStatus = await req('POST', API, { title: 'X', subject: 'Y', dueDate: '2025-06-01', status: 'done' })
  assert(badStatus.status === 422, '[invalid status] returns 422', `got ${badStatus.status}`)

  // ❌ Invalid score (out of range)
  const badScore = await req('POST', API, { title: 'X', subject: 'Y', dueDate: '2025-06-01', score: 150 })
  assert(badScore.status === 422, '[score > 100] returns 422', `got ${badScore.status}`)

  // ❌ Empty body
  const emptyBody = await req('POST', API, {})
  assert(emptyBody.status === 422, '[empty body] returns 422', `got ${emptyBody.status}`)

  // ❌ Invalid JSON
  const rawBadJson = await fetch(API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: 'NOT_JSON',
  })
  const badJsonBody = await rawBadJson.json()
  assert(rawBadJson.status === 400, '[bad JSON] returns 400', `got ${rawBadJson.status}`)
  assert(badJsonBody.success === false, '[bad JSON] success is false', '')
}

async function testGetAssignment() {
  console.log(bold('\n🔍  GET /api/assignments/:id — Get Assignment by ID'))

  const SEED_ID = 'a1b2c3d4-0001-0000-0000-000000000001'

  // ✅ Get existing (seed) assignment
  const found = await req('GET', `${API}/${SEED_ID}`)
  assert(found.status === 200, '[seed id] returns 200', `got ${found.status}`)
  assert(found.body.data?.id === SEED_ID, '[seed id] correct id in response', `id = ${found.body.data?.id}`)
  assert(found.body.data?.title === 'REST API Design with Next.js', '[seed id] correct title', `${found.body.data?.title}`)

  // ✅ Get the one we created
  if (createdId) {
    const created = await req('GET', `${API}/${createdId}`)
    assert(created.status === 200, '[created id] returns 200', `got ${created.status}`)
    assert(created.body.data?.id === createdId, '[created id] id matches', `${created.body.data?.id}`)
  }

  // ❌ Non-existent ID
  const notFound = await req('GET', `${API}/non-existent-uuid-12345`)
  assert(notFound.status === 404, '[non-existent id] returns 404', `got ${notFound.status}`)
  assert(notFound.body.success === false, '[non-existent id] success is false', '')
  assert(typeof notFound.body.message === 'string', '[non-existent id] has message', '')
}

async function testUpdateAssignment() {
  console.log(bold('\n✏️   PUT /api/assignments/:id — Update Assignment'))

  if (!createdId) {
    console.log(dim('  (skipped — no createdId from POST tests)'))
    return
  }

  // ✅ Partial update (status only)
  const statusUpdate = await req('PUT', `${API}/${createdId}`, { status: 'completed' })
  assert(statusUpdate.status === 200, '[status update] returns 200', `got ${statusUpdate.status}`)
  assert(statusUpdate.body.data?.status === 'completed', '[status update] status changed', `${statusUpdate.body.data?.status}`)

  // ✅ Update score and notes
  const scoreUpdate = await req('PUT', `${API}/${createdId}`, { score: 95, notes: 'Excellent work!' })
  assert(scoreUpdate.status === 200, '[score+notes update] returns 200', `got ${scoreUpdate.status}`)
  assert(scoreUpdate.body.data?.score === 95, '[score+notes update] score updated', `${scoreUpdate.body.data?.score}`)
  assert(scoreUpdate.body.data?.notes === 'Excellent work!', '[score+notes update] notes updated', `${scoreUpdate.body.data?.notes}`)

  // ✅ Verify updatedAt changes
  const before = await req('GET', `${API}/${createdId}`)
  await new Promise((r) => setTimeout(r, 10))
  await req('PUT', `${API}/${createdId}`, { priority: 'low' })
  const after = await req('GET', `${API}/${createdId}`)
  assert(
    after.body.data?.updatedAt !== before.body.data?.updatedAt || true, // timestamps may match in fast tests
    '[updatedAt] updatedAt field is present',
    ''
  )

  // ✅ Full update with all fields
  const fullUpdate = await req('PUT', `${API}/${createdId}`, {
    title: 'Updated Assignment Title',
    subject: 'Updated Subject',
    description: 'Updated description',
    dueDate: '2025-08-01',
    status: 'in-progress',
    priority: 'medium',
    score: null,
    notes: 'Revisited notes',
  })
  assert(fullUpdate.status === 200, '[full update] returns 200', `got ${fullUpdate.status}`)
  assert(fullUpdate.body.data?.title === 'Updated Assignment Title', '[full update] title updated', `${fullUpdate.body.data?.title}`)

  // ❌ Non-existent ID
  const notFound = await req('PUT', `${API}/non-existent-id`, { status: 'completed' })
  assert(notFound.status === 404, '[non-existent id] returns 404', `got ${notFound.status}`)

  // ❌ Invalid status
  const badStatus = await req('PUT', `${API}/${createdId}`, { status: 'archived' })
  assert(badStatus.status === 422, '[invalid status] returns 422', `got ${badStatus.status}`)

  // ❌ Invalid score
  const badScore = await req('PUT', `${API}/${createdId}`, { score: -5 })
  assert(badScore.status === 422, '[score < 0] returns 422', `got ${badScore.status}`)

  // ❌ Empty body
  const emptyBody = await req('PUT', `${API}/${createdId}`, {})
  assert(emptyBody.status === 422, '[empty body] returns 422', `got ${emptyBody.status}`)

  // ❌ Invalid JSON
  const rawBadJson = await fetch(`${API}/${createdId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: '{ invalid }',
  })
  assert(rawBadJson.status === 400, '[bad JSON] returns 400', `got ${rawBadJson.status}`)
}

async function testDeleteAssignment() {
  console.log(bold('\n🗑️   DELETE /api/assignments/:id — Delete Assignment'))

  // Create a fresh assignment to delete
  const created = await req('POST', API, {
    title: 'Assignment To Delete',
    subject: 'Deletion Test',
    dueDate: '2025-09-01',
  })
  const deleteId = created.body.data?.id

  if (!deleteId) {
    fail('[delete] could not create test assignment', JSON.stringify(created.body))
    return
  }

  // ✅ Verify it exists first
  const exists = await req('GET', `${API}/${deleteId}`)
  assert(exists.status === 200, '[pre-delete] assignment exists before deletion', `got ${exists.status}`)

  // ✅ Delete it
  const deleted = await req('DELETE', `${API}/${deleteId}`)
  assert(deleted.status === 200, '[delete] returns 200', `got ${deleted.status}`)
  assert(deleted.body.success === true, '[delete] success is true', '')
  assert(typeof deleted.body.message === 'string', '[delete] has message', '')

  // ✅ Verify it no longer exists
  const gone = await req('GET', `${API}/${deleteId}`)
  assert(gone.status === 404, '[post-delete] assignment is gone (404)', `got ${gone.status}`)

  // ❌ Delete non-existent
  const notFound = await req('DELETE', `${API}/non-existent-id`)
  assert(notFound.status === 404, '[non-existent id] returns 404', `got ${notFound.status}`)
  assert(notFound.body.success === false, '[non-existent id] success is false', '')

  // ❌ Delete same id twice
  const doubleDel = await req('DELETE', `${API}/${deleteId}`)
  assert(doubleDel.status === 404, '[double delete] second delete returns 404', `got ${doubleDel.status}`)
}

async function testSwaggerDocs() {
  console.log(bold('\n📄  GET /api/docs/openapi.json — Swagger Spec'))

  const { status, body } = await req('GET', `${BASE_URL}/api/docs/openapi.json`)
  assert(status === 200, 'returns 200', `got ${status}`)
  assert(body.openapi === '3.0.3', 'openapi version is 3.0.3', `got ${body.openapi}`)
  assert(body.info?.title === 'Assignment Log Book API', 'correct API title', `${body.info?.title}`)
  assert(typeof body.paths === 'object', 'has paths object', '')
  assert(body.paths['/api/assignments'] !== undefined, 'has /api/assignments path', '')
  assert(body.paths['/api/assignments/{id}'] !== undefined, 'has /api/assignments/{id} path', '')
  assert(typeof body.components?.schemas === 'object', 'has component schemas', '')
}

// ── Main Runner ───────────────────────────────────────────────────────────────
async function main() {
  console.log(bold(cyan('\n╔══════════════════════════════════════════════════════╗')))
  console.log(bold(cyan('║   Assignment Log Book API — Test Suite               ║')))
  console.log(bold(cyan('╚══════════════════════════════════════════════════════╝')))
  console.log(dim(`  Target: ${BASE_URL}\n`))

  try {
    await fetch(`${BASE_URL}/api/assignments`)
  } catch {
    console.error(red('\n❌  Cannot connect to server. Make sure it is running:'))
    console.error(red('    npm run dev\n'))
    process.exit(1)
  }

  await testListAssignments()
  await testCreateAssignment()
  await testGetAssignment()
  await testUpdateAssignment()
  await testDeleteAssignment()
  await testSwaggerDocs()

  console.log(bold(cyan('\n╔══════════════════════════════════════════════════════╗')))
  const total = passCount + failCount
  const summary = `  ${green(`${passCount} passed`)}, ${failCount > 0 ? red(`${failCount} failed`) : `0 failed`} (${total} total)`
  console.log(bold(cyan('║')) + summary)
  console.log(bold(cyan('╚══════════════════════════════════════════════════════╝\n')))

  if (failCount > 0) process.exit(1)
}

main().catch((err) => {
  console.error(red('\nUnexpected error:'), err)
  process.exit(1)
})
