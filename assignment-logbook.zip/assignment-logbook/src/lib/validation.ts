// src/lib/validation.ts

import { CreateAssignmentDto, UpdateAssignmentDto } from './store'

const VALID_STATUSES = ['pending', 'in-progress', 'completed', 'overdue']
const VALID_PRIORITIES = ['low', 'medium', 'high']
const DATE_REGEX = /^\d{4}-\d{2}-\d{2}$/

export interface ValidationError {
  field: string
  message: string
}

export function validateCreate(body: unknown): { errors: ValidationError[]; dto?: CreateAssignmentDto } {
  const errors: ValidationError[] = []

  if (!body || typeof body !== 'object') {
    return { errors: [{ field: 'body', message: 'Request body must be a JSON object' }] }
  }

  const b = body as Record<string, unknown>

  // Required fields
  if (!b.title || typeof b.title !== 'string' || b.title.trim() === '') {
    errors.push({ field: 'title', message: 'title is required and must be a non-empty string' })
  }
  if (!b.subject || typeof b.subject !== 'string' || b.subject.trim() === '') {
    errors.push({ field: 'subject', message: 'subject is required and must be a non-empty string' })
  }
  if (!b.dueDate || typeof b.dueDate !== 'string' || !DATE_REGEX.test(b.dueDate)) {
    errors.push({ field: 'dueDate', message: 'dueDate is required and must be in YYYY-MM-DD format' })
  }

  // Optional fields
  if (b.status !== undefined && !VALID_STATUSES.includes(b.status as string)) {
    errors.push({ field: 'status', message: `status must be one of: ${VALID_STATUSES.join(', ')}` })
  }
  if (b.priority !== undefined && !VALID_PRIORITIES.includes(b.priority as string)) {
    errors.push({ field: 'priority', message: `priority must be one of: ${VALID_PRIORITIES.join(', ')}` })
  }
  if (b.score !== undefined && b.score !== null) {
    const score = Number(b.score)
    if (isNaN(score) || score < 0 || score > 100) {
      errors.push({ field: 'score', message: 'score must be a number between 0 and 100, or null' })
    }
  }

  if (errors.length > 0) return { errors }

  return {
    errors: [],
    dto: {
      title: (b.title as string).trim(),
      subject: (b.subject as string).trim(),
      description: typeof b.description === 'string' ? b.description.trim() : undefined,
      dueDate: b.dueDate as string,
      status: b.status as CreateAssignmentDto['status'],
      priority: b.priority as CreateAssignmentDto['priority'],
      score: b.score !== undefined ? (b.score as number | null) : undefined,
      notes: typeof b.notes === 'string' ? b.notes : undefined,
    },
  }
}

export function validateUpdate(body: unknown): { errors: ValidationError[]; dto?: UpdateAssignmentDto } {
  const errors: ValidationError[] = []

  if (!body || typeof body !== 'object') {
    return { errors: [{ field: 'body', message: 'Request body must be a JSON object' }] }
  }

  const b = body as Record<string, unknown>

  if (Object.keys(b).length === 0) {
    return { errors: [{ field: 'body', message: 'At least one field must be provided for update' }] }
  }

  if (b.title !== undefined && (typeof b.title !== 'string' || b.title.trim() === '')) {
    errors.push({ field: 'title', message: 'title must be a non-empty string' })
  }
  if (b.subject !== undefined && (typeof b.subject !== 'string' || b.subject.trim() === '')) {
    errors.push({ field: 'subject', message: 'subject must be a non-empty string' })
  }
  if (b.dueDate !== undefined && (typeof b.dueDate !== 'string' || !DATE_REGEX.test(b.dueDate))) {
    errors.push({ field: 'dueDate', message: 'dueDate must be in YYYY-MM-DD format' })
  }
  if (b.status !== undefined && !VALID_STATUSES.includes(b.status as string)) {
    errors.push({ field: 'status', message: `status must be one of: ${VALID_STATUSES.join(', ')}` })
  }
  if (b.priority !== undefined && !VALID_PRIORITIES.includes(b.priority as string)) {
    errors.push({ field: 'priority', message: `priority must be one of: ${VALID_PRIORITIES.join(', ')}` })
  }
  if (b.score !== undefined && b.score !== null) {
    const score = Number(b.score)
    if (isNaN(score) || score < 0 || score > 100) {
      errors.push({ field: 'score', message: 'score must be a number between 0 and 100, or null' })
    }
  }

  if (errors.length > 0) return { errors }

  const dto: UpdateAssignmentDto = {}
  if (b.title !== undefined) dto.title = (b.title as string).trim()
  if (b.subject !== undefined) dto.subject = (b.subject as string).trim()
  if (b.description !== undefined) dto.description = (b.description as string).trim()
  if (b.dueDate !== undefined) dto.dueDate = b.dueDate as string
  if (b.status !== undefined) dto.status = b.status as UpdateAssignmentDto['status']
  if (b.priority !== undefined) dto.priority = b.priority as UpdateAssignmentDto['priority']
  if (b.score !== undefined) dto.score = b.score as number | null
  if (b.notes !== undefined) dto.notes = b.notes as string

  return { errors: [], dto }
}
