// src/lib/store.ts
// In-memory store (replace with real DB like MongoDB/PostgreSQL in production)

export type AssignmentStatus = 'pending' | 'in-progress' | 'completed' | 'overdue'
export type AssignmentPriority = 'low' | 'medium' | 'high'

export interface Assignment {
  id: string
  title: string
  subject: string
  description: string
  dueDate: string          // ISO 8601 date string e.g. "2025-04-01"
  status: AssignmentStatus
  priority: AssignmentPriority
  score?: number | null    // 0–100, null if not graded yet
  notes?: string
  createdAt: string
  updatedAt: string
}

export interface CreateAssignmentDto {
  title: string
  subject: string
  description?: string
  dueDate: string
  status?: AssignmentStatus
  priority?: AssignmentPriority
  score?: number | null
  notes?: string
}

export interface UpdateAssignmentDto {
  title?: string
  subject?: string
  description?: string
  dueDate?: string
  status?: AssignmentStatus
  priority?: AssignmentPriority
  score?: number | null
  notes?: string
}

// ── Seed Data ────────────────────────────────────────────────────────────────
const seedAssignments: Assignment[] = [
  {
    id: 'a1b2c3d4-0001-0000-0000-000000000001',
    title: 'REST API Design with Next.js',
    subject: 'Web Development',
    description: 'Build a full CRUD REST API using Next.js App Router with Swagger docs.',
    dueDate: '2025-04-10',
    status: 'in-progress',
    priority: 'high',
    score: null,
    notes: 'Remember to add error handling and validation.',
    createdAt: '2025-03-01T08:00:00.000Z',
    updatedAt: '2025-03-05T10:00:00.000Z',
  },
  {
    id: 'a1b2c3d4-0001-0000-0000-000000000002',
    title: 'Database Normalization Essay',
    subject: 'Database Systems',
    description: 'Write a 2000-word essay explaining 1NF, 2NF, and 3NF with examples.',
    dueDate: '2025-03-20',
    status: 'completed',
    priority: 'medium',
    score: 88,
    notes: 'Submitted on time.',
    createdAt: '2025-02-20T09:00:00.000Z',
    updatedAt: '2025-03-18T14:00:00.000Z',
  },
  {
    id: 'a1b2c3d4-0001-0000-0000-000000000003',
    title: 'Algorithm Analysis — Sorting',
    subject: 'Data Structures & Algorithms',
    description: 'Compare time/space complexity of Bubble, Merge, and Quick Sort.',
    dueDate: '2025-04-01',
    status: 'pending',
    priority: 'high',
    score: null,
    notes: '',
    createdAt: '2025-03-03T11:00:00.000Z',
    updatedAt: '2025-03-03T11:00:00.000Z',
  },
]

// ── Global Store ──────────────────────────────────────────────────────────────
declare global {
  // eslint-disable-next-line no-var
  var __assignmentStore: Assignment[] | undefined
}

function getStore(): Assignment[] {
  if (!global.__assignmentStore) {
    global.__assignmentStore = [...seedAssignments]
  }
  return global.__assignmentStore
}

// ── CRUD helpers ──────────────────────────────────────────────────────────────
export function getAllAssignments(): Assignment[] {
  return getStore()
}

export function getAssignmentById(id: string): Assignment | undefined {
  return getStore().find((a) => a.id === id)
}

export function createAssignment(dto: CreateAssignmentDto): Assignment {
  const store = getStore()
  const now = new Date().toISOString()
  const newAssignment: Assignment = {
    id: crypto.randomUUID(),
    title: dto.title,
    subject: dto.subject,
    description: dto.description ?? '',
    dueDate: dto.dueDate,
    status: dto.status ?? 'pending',
    priority: dto.priority ?? 'medium',
    score: dto.score ?? null,
    notes: dto.notes ?? '',
    createdAt: now,
    updatedAt: now,
  }
  store.push(newAssignment)
  return newAssignment
}

export function updateAssignment(id: string, dto: UpdateAssignmentDto): Assignment | null {
  const store = getStore()
  const idx = store.findIndex((a) => a.id === id)
  if (idx === -1) return null

  const updated: Assignment = {
    ...store[idx],
    ...dto,
    id,
    createdAt: store[idx].createdAt,
    updatedAt: new Date().toISOString(),
  }
  store[idx] = updated
  return updated
}

export function deleteAssignment(id: string): boolean {
  const store = getStore()
  const idx = store.findIndex((a) => a.id === id)
  if (idx === -1) return false
  store.splice(idx, 1)
  return true
}
