'use client'
// src/app/api-docs/page.tsx
import { useEffect, useState } from 'react'

export default function ApiDocsPage() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', fontFamily: 'monospace' }}>
        Loading API docs…
      </div>
    )
  }

  return <SwaggerWrapper />
}

function SwaggerWrapper() {
  useEffect(() => {
    // Dynamically load Swagger UI to avoid SSR issues
    const link = document.createElement('link')
    link.rel = 'stylesheet'
    link.href = 'https://unpkg.com/swagger-ui-dist@5.17.0/swagger-ui.css'
    document.head.appendChild(link)

    const script = document.createElement('script')
    script.src = 'https://unpkg.com/swagger-ui-dist@5.17.0/swagger-ui-bundle.js'
    script.onload = () => {
      // @ts-ignore
      window.SwaggerUIBundle({
        url: '/api/docs/openapi.json',
        dom_id: '#swagger-ui',
        presets: [
          // @ts-ignore
          window.SwaggerUIBundle.presets.apis,
          // @ts-ignore
          window.SwaggerUIBundle.SwaggerUIStandalonePreset,
        ],
        layout: 'BaseLayout',
        deepLinking: true,
        displayRequestDuration: true,
        tryItOutEnabled: true,
        defaultModelsExpandDepth: 2,
        defaultModelExpandDepth: 2,
      })
    }
    document.body.appendChild(script)
  }, [])

  return (
    <>
      <style>{`
        body { margin: 0; }
        .swagger-ui .topbar { background: #1a1a2e; }
        .swagger-ui .topbar .download-url-wrapper .select-label select { border: 1px solid #6e56cf; }
      `}</style>
      <div id="swagger-ui" />
    </>
  )
}
