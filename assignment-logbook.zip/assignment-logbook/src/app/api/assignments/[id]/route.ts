// src/app/api/assignments/[id]/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { getAssignmentById, updateAssignment, deleteAssignment } from '@/lib/store'
import { validateUpdate } from '@/lib/validation'

interface RouteParams {
  params: { id: string }
}

/**
 * GET /api/assignments/:id
 * Returns a single assignment by ID.
 */
export async function GET(_request: NextRequest, { params }: RouteParams) {
  try {
    const assignment = getAssignmentById(params.id)

    if (!assignment) {
      return NextResponse.json(
        { success: false, message: `Assignment with id '${params.id}' not found` },
        { status: 404 }
      )
    }

    return NextResponse.json({ success: true, data: assignment }, { status: 200 })
  } catch (error) {
    return NextResponse.json(
      { success: false, message: 'Internal server error', error: String(error) },
      { status: 500 }
    )
  }
}

/**
 * PUT /api/assignments/:id
 * Partially or fully updates an assignment.
 * All fields are optional; at least one must be provided.
 */
export async function PUT(request: NextRequest, { params }: RouteParams) {
  try {
    // Check exists first
    const existing = getAssignmentById(params.id)
    if (!existing) {
      return NextResponse.json(
        { success: false, message: `Assignment with id '${params.id}' not found` },
        { status: 404 }
      )
    }

    let body: unknown
    try {
      body = await request.json()
    } catch {
      return NextResponse.json(
        { success: false, message: 'Invalid JSON body' },
        { status: 400 }
      )
    }

    const { errors, dto } = validateUpdate(body)
    if (errors.length > 0) {
      return NextResponse.json(
        { success: false, message: 'Validation failed', errors },
        { status: 422 }
      )
    }

    const updated = updateAssignment(params.id, dto!)

    return NextResponse.json(
      { success: true, message: 'Assignment updated successfully', data: updated },
      { status: 200 }
    )
  } catch (error) {
    return NextResponse.json(
      { success: false, message: 'Internal server error', error: String(error) },
      { status: 500 }
    )
  }
}

/**
 * DELETE /api/assignments/:id
 * Deletes an assignment by ID.
 */
export async function DELETE(_request: NextRequest, { params }: RouteParams) {
  try {
    const existing = getAssignmentById(params.id)
    if (!existing) {
      return NextResponse.json(
        { success: false, message: `Assignment with id '${params.id}' not found` },
        { status: 404 }
      )
    }

    deleteAssignment(params.id)

    return NextResponse.json(
      { success: true, message: `Assignment '${existing.title}' deleted successfully` },
      { status: 200 }
    )
  } catch (error) {
    return NextResponse.json(
      { success: false, message: 'Internal server error', error: String(error) },
      { status: 500 }
    )
  }
}
