// src/app/api/assignments/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { getAllAssignments, createAssignment } from '@/lib/store'
import { validateCreate } from '@/lib/validation'

/**
 * GET /api/assignments
 * Returns a list of all assignments, with optional filtering via query params.
 *
 * Query params:
 *   status   - filter by status (pending|in-progress|completed|overdue)
 *   priority - filter by priority (low|medium|high)
 *   subject  - filter by subject (case-insensitive substring match)
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const priority = searchParams.get('priority')
    const subject = searchParams.get('subject')

    let assignments = getAllAssignments()

    if (status) {
      assignments = assignments.filter((a) => a.status === status)
    }
    if (priority) {
      assignments = assignments.filter((a) => a.priority === priority)
    }
    if (subject) {
      assignments = assignments.filter((a) =>
        a.subject.toLowerCase().includes(subject.toLowerCase())
      )
    }

    return NextResponse.json(
      {
        success: true,
        count: assignments.length,
        data: assignments,
      },
      { status: 200 }
    )
  } catch (error) {
    return NextResponse.json(
      { success: false, message: 'Internal server error', error: String(error) },
      { status: 500 }
    )
  }
}

/**
 * POST /api/assignments
 * Creates a new assignment.
 *
 * Required body fields: title, subject, dueDate
 * Optional: description, status, priority, score, notes
 */
export async function POST(request: NextRequest) {
  try {
    let body: unknown
    try {
      body = await request.json()
    } catch {
      return NextResponse.json(
        { success: false, message: 'Invalid JSON body' },
        { status: 400 }
      )
    }

    const { errors, dto } = validateCreate(body)
    if (errors.length > 0) {
      return NextResponse.json(
        { success: false, message: 'Validation failed', errors },
        { status: 422 }
      )
    }

    const assignment = createAssignment(dto!)

    return NextResponse.json(
      { success: true, message: 'Assignment created successfully', data: assignment },
      { status: 201 }
    )
  } catch (error) {
    return NextResponse.json(
      { success: false, message: 'Internal server error', error: String(error) },
      { status: 500 }
    )
  }
}
