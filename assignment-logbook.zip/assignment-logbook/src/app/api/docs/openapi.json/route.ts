// src/app/api/docs/openapi.json/route.ts
import { NextResponse } from 'next/server'

const openApiSpec = {
  openapi: '3.0.3',
  info: {
    title: 'Assignment Log Book API',
    version: '1.0.0',
    description:
      'A RESTful API for managing student assignment records. Built with Next.js App Router.',
    contact: {
      name: 'Assignment Log Book',
      email: 'dev@assignment-logbook.example.com',
    },
  },
  servers: [
    { url: 'http://localhost:3000', description: 'Local Development' },
    { url: 'https://your-deployment.vercel.app', description: 'Production' },
  ],
  tags: [{ name: 'Assignments', description: 'CRUD operations for assignments' }],
  paths: {
    '/api/assignments': {
      get: {
        tags: ['Assignments'],
        summary: 'List all assignments',
        description:
          'Returns a list of all assignments. Supports optional filtering by status, priority, and subject.',
        operationId: 'listAssignments',
        parameters: [
          {
            name: 'status',
            in: 'query',
            description: 'Filter by assignment status',
            required: false,
            schema: { $ref: '#/components/schemas/AssignmentStatus' },
          },
          {
            name: 'priority',
            in: 'query',
            description: 'Filter by priority level',
            required: false,
            schema: { $ref: '#/components/schemas/AssignmentPriority' },
          },
          {
            name: 'subject',
            in: 'query',
            description: 'Filter by subject (case-insensitive substring match)',
            required: false,
            schema: { type: 'string', example: 'Web Development' },
          },
        ],
        responses: {
          '200': {
            description: 'Successful response',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    success: { type: 'boolean', example: true },
                    count: { type: 'integer', example: 3 },
                    data: {
                      type: 'array',
                      items: { $ref: '#/components/schemas/Assignment' },
                    },
                  },
                },
              },
            },
          },
          '500': { $ref: '#/components/responses/InternalServerError' },
        },
      },
      post: {
        tags: ['Assignments'],
        summary: 'Create a new assignment',
        description: 'Creates a new assignment entry in the log book.',
        operationId: 'createAssignment',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/CreateAssignmentRequest' },
              examples: {
                basic: {
                  summary: 'Minimal required fields',
                  value: {
                    title: 'Final Project Proposal',
                    subject: 'Software Engineering',
                    dueDate: '2025-05-01',
                  },
                },
                full: {
                  summary: 'All fields provided',
                  value: {
                    title: 'Machine Learning Report',
                    subject: 'Artificial Intelligence',
                    description: 'Explore supervised learning algorithms and their applications.',
                    dueDate: '2025-04-15',
                    status: 'in-progress',
                    priority: 'high',
                    score: null,
                    notes: 'Focus on neural networks section.',
                  },
                },
              },
            },
          },
        },
        responses: {
          '201': {
            description: 'Assignment created successfully',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    success: { type: 'boolean', example: true },
                    message: { type: 'string', example: 'Assignment created successfully' },
                    data: { $ref: '#/components/schemas/Assignment' },
                  },
                },
              },
            },
          },
          '400': { $ref: '#/components/responses/BadRequest' },
          '422': { $ref: '#/components/responses/ValidationError' },
          '500': { $ref: '#/components/responses/InternalServerError' },
        },
      },
    },
    '/api/assignments/{id}': {
      parameters: [
        {
          name: 'id',
          in: 'path',
          required: true,
          description: 'Unique assignment UUID',
          schema: { type: 'string', format: 'uuid', example: 'a1b2c3d4-0001-0000-0000-000000000001' },
        },
      ],
      get: {
        tags: ['Assignments'],
        summary: 'Get assignment by ID',
        description: 'Returns a single assignment by its unique ID.',
        operationId: 'getAssignment',
        responses: {
          '200': {
            description: 'Assignment found',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    success: { type: 'boolean', example: true },
                    data: { $ref: '#/components/schemas/Assignment' },
                  },
                },
              },
            },
          },
          '404': { $ref: '#/components/responses/NotFound' },
          '500': { $ref: '#/components/responses/InternalServerError' },
        },
      },
      put: {
        tags: ['Assignments'],
        summary: 'Update an assignment',
        description: 'Partially or fully updates an existing assignment. All body fields are optional.',
        operationId: 'updateAssignment',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/UpdateAssignmentRequest' },
              examples: {
                markCompleted: {
                  summary: 'Mark as completed with score',
                  value: { status: 'completed', score: 95 },
                },
                changePriority: {
                  summary: 'Update priority and notes',
                  value: { priority: 'high', notes: 'Deadline moved up!' },
                },
              },
            },
          },
        },
        responses: {
          '200': {
            description: 'Assignment updated successfully',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    success: { type: 'boolean', example: true },
                    message: { type: 'string', example: 'Assignment updated successfully' },
                    data: { $ref: '#/components/schemas/Assignment' },
                  },
                },
              },
            },
          },
          '400': { $ref: '#/components/responses/BadRequest' },
          '404': { $ref: '#/components/responses/NotFound' },
          '422': { $ref: '#/components/responses/ValidationError' },
          '500': { $ref: '#/components/responses/InternalServerError' },
        },
      },
      delete: {
        tags: ['Assignments'],
        summary: 'Delete an assignment',
        description: 'Permanently deletes an assignment by ID.',
        operationId: 'deleteAssignment',
        responses: {
          '200': {
            description: 'Assignment deleted successfully',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    success: { type: 'boolean', example: true },
                    message: { type: 'string', example: "Assignment 'REST API Design with Next.js' deleted successfully" },
                  },
                },
              },
            },
          },
          '404': { $ref: '#/components/responses/NotFound' },
          '500': { $ref: '#/components/responses/InternalServerError' },
        },
      },
    },
  },
  components: {
    schemas: {
      AssignmentStatus: {
        type: 'string',
        enum: ['pending', 'in-progress', 'completed', 'overdue'],
        example: 'pending',
      },
      AssignmentPriority: {
        type: 'string',
        enum: ['low', 'medium', 'high'],
        example: 'medium',
      },
      Assignment: {
        type: 'object',
        properties: {
          id: { type: 'string', format: 'uuid', example: 'a1b2c3d4-0001-0000-0000-000000000001' },
          title: { type: 'string', example: 'REST API Design with Next.js' },
          subject: { type: 'string', example: 'Web Development' },
          description: { type: 'string', example: 'Build a full CRUD REST API using Next.js.' },
          dueDate: { type: 'string', format: 'date', example: '2025-04-10' },
          status: { $ref: '#/components/schemas/AssignmentStatus' },
          priority: { $ref: '#/components/schemas/AssignmentPriority' },
          score: { type: 'number', nullable: true, minimum: 0, maximum: 100, example: 88 },
          notes: { type: 'string', example: 'Remember to add error handling.' },
          createdAt: { type: 'string', format: 'date-time', example: '2025-03-01T08:00:00.000Z' },
          updatedAt: { type: 'string', format: 'date-time', example: '2025-03-05T10:00:00.000Z' },
        },
        required: ['id', 'title', 'subject', 'dueDate', 'status', 'priority', 'createdAt', 'updatedAt'],
      },
      CreateAssignmentRequest: {
        type: 'object',
        required: ['title', 'subject', 'dueDate'],
        properties: {
          title: { type: 'string', minLength: 1, example: 'Final Project Proposal' },
          subject: { type: 'string', minLength: 1, example: 'Software Engineering' },
          description: { type: 'string', example: 'Detailed project proposal with timeline.' },
          dueDate: { type: 'string', format: 'date', example: '2025-05-01' },
          status: { $ref: '#/components/schemas/AssignmentStatus' },
          priority: { $ref: '#/components/schemas/AssignmentPriority' },
          score: { type: 'number', nullable: true, minimum: 0, maximum: 100 },
          notes: { type: 'string', example: 'Check rubric before submitting.' },
        },
      },
      UpdateAssignmentRequest: {
        type: 'object',
        minProperties: 1,
        properties: {
          title: { type: 'string', minLength: 1 },
          subject: { type: 'string', minLength: 1 },
          description: { type: 'string' },
          dueDate: { type: 'string', format: 'date' },
          status: { $ref: '#/components/schemas/AssignmentStatus' },
          priority: { $ref: '#/components/schemas/AssignmentPriority' },
          score: { type: 'number', nullable: true, minimum: 0, maximum: 100 },
          notes: { type: 'string' },
        },
      },
    },
    responses: {
      BadRequest: {
        description: 'Bad request — invalid JSON or malformed input',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                success: { type: 'boolean', example: false },
                message: { type: 'string', example: 'Invalid JSON body' },
              },
            },
          },
        },
      },
      ValidationError: {
        description: 'Unprocessable entity — validation errors',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                success: { type: 'boolean', example: false },
                message: { type: 'string', example: 'Validation failed' },
                errors: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      field: { type: 'string', example: 'dueDate' },
                      message: { type: 'string', example: 'dueDate is required and must be in YYYY-MM-DD format' },
                    },
                  },
                },
              },
            },
          },
        },
      },
      NotFound: {
        description: 'Assignment not found',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                success: { type: 'boolean', example: false },
                message: { type: 'string', example: "Assignment with id 'xyz' not found" },
              },
            },
          },
        },
      },
      InternalServerError: {
        description: 'Internal server error',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                success: { type: 'boolean', example: false },
                message: { type: 'string', example: 'Internal server error' },
              },
            },
          },
        },
      },
    },
  },
}

export async function GET() {
  return NextResponse.json(openApiSpec, {
    status: 200,
    headers: { 'Access-Control-Allow-Origin': '*' },
  })
}
